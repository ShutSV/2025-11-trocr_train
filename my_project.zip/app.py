from fastapi import FastAPI, APIRouter, Request, status
from fastapi.responses import ORJSONResponse
import datetime
from typing import Dict

from src.api import api_router


app = FastAPI(title="OCR Server", version="1.0.0")
app.include_router(router=api_router)


@app.get(
    path="/",
    status_code=status.HTTP_200_OK,
    response_model=Dict,
    name="Health check with endpoints tree",
)
async def health_check(request: Request):
    app = request.app

    endpoints = []
    for route in app.routes:
        if hasattr(route, "methods") and hasattr(route, "path"):
            endpoints.append({
                "path": route.path,
                "methods": list(route.methods) if hasattr(route, "methods") else [],
                "name": getattr(route, "name", None)
            })

    return {
        "status": "healthy",
        "timestamp": datetime.datetime.now().isoformat(),
        "endpoints_tree": endpoints,
        "total": len(endpoints)
    }
