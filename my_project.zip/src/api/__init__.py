from .router import router as api_router


__all__ = [
    "api_router",
]