from .router import router as training_router


__all__ = [
    "training_router",
]