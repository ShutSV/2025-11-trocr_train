from .router import router as inference_router


__all__ = [
    "inference_router",
]