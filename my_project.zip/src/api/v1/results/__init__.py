from .router import router as results_router


__all__ = [
    "results_router",
]