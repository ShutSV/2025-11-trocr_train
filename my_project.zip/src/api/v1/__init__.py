from .router import router as v1_router


__all__ = [
    "v1_router",
]